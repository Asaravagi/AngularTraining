import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AuthenticationServiceService } from '../service/authentication-service.service';
import { Router } from '@angular/router';
import { FilmServiceService } from '../service/filmSearch-Service.service';

@Component({
  selector: 'app-film-search',
  templateUrl: './film-search.component.html',
  styleUrls: ['./film-search.component.scss']
})
export class FilmSearchComponent implements OnInit {

  constructor(private authService: AuthenticationServiceService,private service :FilmServiceService,private router: Router) { }
  films=[];
  FormSubmit=false;

  ngOnInit(): void {
    this.FormSubmit=true;
  }

  @Output() loggedIn: EventEmitter<any> = new EventEmitter<any>();

  addNewTask(task: any): void {
    this.loggedIn.emit(task);
  }

  searchMovie!: string;

  searchFilms(){
    if(this.searchMovie!==undefined)
    {this.service.search(this.searchMovie).subscribe(
      (data:any)=>{
        this.router.navigateByUrl("/film");
        this.service.films=data;
        this.FormSubmit=true;
      }
    )}
  }
   
  logout(){
    this.authService.logOut();
  }
}
