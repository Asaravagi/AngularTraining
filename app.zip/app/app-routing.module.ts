import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FilmSearchComponent } from './film-search/film-search.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { FilmComponent } from './film/film.component';

const routes: Routes = [
  {path: 'login', component: LoginFormComponent},
  {path: 'search', component: FilmSearchComponent},
  {path: 'register', component: RegisterFormComponent},
  {path: 'film', component: FilmComponent},
  {path: '', component:LoginFormComponent},
  {path: '**', component:NotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
